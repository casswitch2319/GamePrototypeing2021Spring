var c = document.querySelector('canvas');
var ctx = c.getContext('2d')

var ball 


function ball(x,y,w,h,color)
{
	
	//Default Values
	if(x == undefined)
		this.x = 0;
	else 
		this.x = x;
	if(y == undefined)
		this.y = 0;
	else 
		this.y = y;
	
	if(w == undefined)
		this.width = this.width/2;
	else 
		this.width = w;
	if(h == undefined)
		this.height = this/this.height/2;
	else 
		this.height = h;
	
		//player's color
	if(color == undefined)
		this.color = "purple";
	else 
		this.color = color;
	
	//player's velocity or speed on each axis
	this.vx = 0
	this.vy = 0
    this.drawCircle = function()
	{
		context.save();
			context.fillStyle = this.color;
			context.beginPath();
			context.translate(this.x, this.y);
			context.arc(0, 0, this.width/2, 0, 360 *Math.PI/180, true);
			context.arc(0, 0, this.width/2, 0, 360 *Math.PI/180, true);
			context.closePath();
			context.fill();
		context.restore();
		
	}	
	
	//This changes the player's position
	this.move = function()
	{
		this.x += this.vx;
		this.y += this.vy;
	}
}